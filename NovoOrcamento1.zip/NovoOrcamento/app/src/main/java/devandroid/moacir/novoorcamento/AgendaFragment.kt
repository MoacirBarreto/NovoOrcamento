package devandroid.moacir.novoorcamento

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import devandroid.moacir.novoorcamento.database.AppDatabase
import devandroid.moacir.novoorcamento.databinding.FragmentAgendaBinding
import devandroid.moacir.novoorcamento.model.Agenda
import devandroid.moacir.novoorcamento.model.Lancamento
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AgendaFragment : Fragment() {

    private var _binding: FragmentAgendaBinding? = null
    private val binding get() = _binding!!
    private lateinit var db: AppDatabase

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAgendaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = AppDatabase.getDatabase(requireContext())

        configurarRecyclerView()
        observarAgenda()
        configurarBotaoAdicionar()
    }

    private fun configurarRecyclerView() {
        binding.rvAgenda.layoutManager = LinearLayoutManager(requireContext())
    }

    private fun observarAgenda() {
        viewLifecycleOwner.lifecycleScope.launch {
            // O collect mantém a lista atualizada em tempo real caso o DB mude
            db.agendaDao().listarAgenda().collect { lista ->
                if (lista.isEmpty()) {
                    binding.txtAvisoVazio.visibility = View.VISIBLE
                    binding.rvAgenda.visibility = View.GONE
                } else {
                    binding.txtAvisoVazio.visibility = View.GONE
                    binding.rvAgenda.visibility = View.VISIBLE

                    binding.rvAgenda.adapter = AgendaAdapter(
                        lista = lista,
                        onConfirmarClick = { item -> confirmarLancamento(item) },
                        onDeleteClick = { item -> excluirDaAgenda(item) },
                        onEditarClick = { item -> abrirEdicao(item) },
                        onItemClick = { item -> abrirEdicao(item) }
                    )
                }
            }
        }
    }

    private fun configurarBotaoAdicionar() {
        binding.fabAdicionarAgenda.setOnClickListener {
            val intent = Intent(requireContext(), NovoLancamentoActivity::class.java)
            intent.putExtra(NovoLancamentoActivity.EXTRA_IS_AGENDA, true)
            startActivity(intent)
        }
    }

    private fun abrirEdicao(agenda: Agenda) {
        val intent = Intent(requireContext(), NovoLancamentoActivity::class.java)
        intent.putExtra(NovoLancamentoActivity.EXTRA_IS_AGENDA, true)
        intent.putExtra(NovoLancamentoActivity.EXTRA_ID, agenda.id)
        startActivity(intent)
    }

    private fun confirmarLancamento(agenda: Agenda) {
        AlertDialog.Builder(requireContext())
            .setTitle("Efetivar Lançamento")
            .setMessage("Deseja transformar '${agenda.descricao}' em um lançamento real mantendo a data original?")
            .setPositiveButton("Sim") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        // 1. Criar lançamento real PRESERVANDO a data da agenda
                        val novoLancamento = Lancamento(
                            id = 0, // Novo ID autogerado na tabela de lançamentos
                            descricao = agenda.descricao,
                            valor = agenda.valor,
                            data = agenda.data, // Mantém a data original (mesmo que vencida)
                            categoriaID = agenda.categoriaID,
                            tipo = agenda.tipo
                        )
                        db.orcamentoDao().upsertLancamento(novoLancamento)

                        // 2. Remover o item da agenda para evitar duplicidade
                        db.agendaDao().deletarAgenda(agenda)
                    }

                    // Notifica o usuário na MainThread
                    Toast.makeText(requireContext(), "Lançamento efetivado com sucesso!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Não", null)
            .show()
    }

    private fun excluirDaAgenda(agenda: Agenda) {
        AlertDialog.Builder(requireContext())
            .setTitle("Excluir Agendamento")
            .setMessage("Tem certeza que deseja remover '${agenda.descricao}' da agenda?")
            .setPositiveButton("Excluir") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        db.agendaDao().deletarAgenda(agenda)
                    }
                    Toast.makeText(requireContext(), "Item removido", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}