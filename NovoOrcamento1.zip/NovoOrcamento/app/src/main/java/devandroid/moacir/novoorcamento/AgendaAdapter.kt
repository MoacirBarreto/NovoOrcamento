package devandroid.moacir.novoorcamento

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import devandroid.moacir.novoorcamento.databinding.ItemAgendaBinding
import devandroid.moacir.novoorcamento.model.Agenda
import devandroid.moacir.novoorcamento.model.TipoLancamento
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class AgendaAdapter(
    private var lista: List<Agenda>,
    private val onConfirmarClick: (Agenda) -> Unit,
    private val onEditarClick: (Agenda) -> Unit,
    private val onDeleteClick: (Agenda) -> Unit,
    private val onItemClick: (Agenda) -> Unit
) : RecyclerView.Adapter<AgendaAdapter.AgendaViewHolder>() {

    private val formatoMoeda = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
    private val formatoData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

    inner class AgendaViewHolder(val binding: ItemAgendaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Agenda) {
            val context = itemView.context

            with(binding) {
                // 1. Preenchimento de dados
                txtItemAgendaDescricao.text = item.descricao
                txtItemAgendaValor.text = formatoMoeda.format(item.valor)
                txtItemAgendaData.text = formatoData.format(Date(item.data))

                // 2. Cor do valor baseado no tipo
                val corValor = if (item.tipo == TipoLancamento.RECEITA) {
                    ContextCompat.getColor(context, R.color.receita)
                } else {
                    ContextCompat.getColor(context, R.color.despesa)
                }
                txtItemAgendaValor.setTextColor(corValor)

                // 3. Lógica de Vencimento (Visual apenas)
                val hoje = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis

                val isVencido = item.data < hoje

                if (isVencido) {
                    // Se vencido, apenas muda a cor da data para vermelho e reduz opacidade do card
                    txtItemAgendaData.setTextColor(Color.RED)
                    root.alpha = 0.8f
                } else {
                    txtItemAgendaData.setTextColor(Color.GRAY)
                    root.alpha = 1.0f
                }

                // 4. GARANTIA: O card e botões NUNCA ficam desabilitados (isEnabled = true)
                root.isEnabled = true
                btnConfirmarPagamento.isEnabled = true

                // 5. Configuração de Cliques
                btnConfirmarPagamento.setOnClickListener { onConfirmarClick(item) }

                // Clique curto abre edição
                root.setOnClickListener { onItemClick(item) }

                // Clique longo abre exclusão
                root.setOnLongClickListener {
                    onDeleteClick(item)
                    true
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AgendaViewHolder {
        val binding = ItemAgendaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AgendaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AgendaViewHolder, position: Int) {
        holder.bind(lista[position])
    }

    override fun getItemCount() = lista.size

    fun atualizarLista(novaLista: List<Agenda>) {
        this.lista = novaLista
        notifyDataSetChanged()
    }
}