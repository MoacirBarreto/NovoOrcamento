package devandroid.moacir.novoorcamento

import android.app.DatePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import devandroid.moacir.novoorcamento.database.AppDatabase
import devandroid.moacir.novoorcamento.databinding.ActivityNovoLancamentoBinding
import devandroid.moacir.novoorcamento.model.Agenda
import devandroid.moacir.novoorcamento.model.Categoria
import devandroid.moacir.novoorcamento.model.Lancamento
import devandroid.moacir.novoorcamento.model.TipoLancamento
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class NovoLancamentoActivity : AppCompatActivity() {

    private val binding by lazy { ActivityNovoLancamentoBinding.inflate(layoutInflater) }
    private val db by lazy { AppDatabase.getDatabase(this) }

    private var categorias: List<Categoria> = emptyList()
    private var dataSelecionadaMillis: Long = System.currentTimeMillis()

    private var idEdicao: Int = -1
    private var isAgenda: Boolean = false

    // Definindo o Watcher como variável global para poder remover/adicionar com segurança
    private val valorWatcher = object : TextWatcher {
        private var current = ""
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            if (s.toString() != current) {
                binding.edtValor.removeTextChangedListener(this)

                val clean = s.toString().replace(Regex("[^0-9]"), "")

                if (clean.isNotEmpty()) {
                    try {
                        val parsed = clean.toDouble()
                        val formatted = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
                            .format(parsed / 100)

                        current = formatted
                        binding.edtValor.setText(formatted)
                        binding.edtValor.setSelection(formatted.length)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    current = ""
                    binding.edtValor.setText("")
                }
                binding.edtValor.addTextChangedListener(this)
            }
        }
    }

    companion object {
        const val EXTRA_ID = "extra_id"
        const val EXTRA_IS_AGENDA = "extra_is_agenda"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        idEdicao = intent.getIntExtra(EXTRA_ID, -1)
        isAgenda = intent.getBooleanExtra(EXTRA_IS_AGENDA, false)

        android.util.Log.d("INICIALIZACAO", "ID: $idEdicao | IsAgenda: $isAgenda")

        inicializarComponentes()
    }

    private fun inicializarComponentes() {
        binding.txtTituloTela.text = if (isAgenda) "Novo Agendamento" else "Novo Lançamento"

        configurarCampoValor()
        configurarCampoData()
        configurarMudancaDeTipo()
        configurarBotaoSalvar()
        atualizarVisibilidadeRepeticao()
        carregarDadosIniciais()
    }

    private fun atualizarVisibilidadeRepeticao() {
        binding.containerRepetir.visibility =
            if (isAgenda && idEdicao == -1) View.VISIBLE else View.GONE

        binding.chkRepetir.setOnCheckedChangeListener { _, isChecked ->
            val vis = if (isChecked) View.VISIBLE else View.GONE
            binding.edtQtdMeses.visibility = vis
            binding.txtMesesLabel.visibility = vis
        }
    }

    private fun carregarDadosIniciais() {
        lifecycleScope.launch {
            categorias = withContext(Dispatchers.IO) { db.orcamentoDao().listarCategorias() }

            val adapter = ArrayAdapter(
                this@NovoLancamentoActivity,
                android.R.layout.simple_spinner_dropdown_item,
                categorias.map { it.nome }
            )
            binding.spinnerCategorias.adapter = adapter

            binding.spinnerCategorias.onItemSelectedListener =
                object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        if (idEdicao == -1 && binding.rbDespesa.isChecked) {
                            atualizarDescricaoPelaCategoria()
                        }
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }

            if (idEdicao != -1) {
                if (isAgenda) carregarAgendaParaEdicao(idEdicao)
                else carregarLancamentoParaEdicao(idEdicao)
            } else {
                atualizarTextoData(Calendar.getInstance())
                if (categorias.isNotEmpty() && binding.rbDespesa.isChecked) {
                    binding.spinnerCategorias.post { atualizarDescricaoPelaCategoria() }
                }
            }
        }
    }

    private suspend fun carregarLancamentoParaEdicao(id: Int) {
        val lanc = withContext(Dispatchers.IO) {
            db.orcamentoDao().listarLancamentosSemFlow().firstOrNull { it.id == id }
        }

        withContext(Dispatchers.Main) {
            if (lanc != null) {
                preencherCampos(lanc.descricao, lanc.valor, lanc.tipo, lanc.data, lanc.categoriaID)
            } else {
                Toast.makeText(this@NovoLancamentoActivity, "Lançamento não encontrado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun carregarAgendaParaEdicao(id: Int) {
        val agend = withContext(Dispatchers.IO) { db.agendaDao().buscarPorId(id) }
        agend?.let { preencherCampos(it.descricao, it.valor, it.tipo, it.data, it.categoriaID) }
    }

    private fun preencherCampos(desc: String, valor: Double, tipo: TipoLancamento, data: Long, catId: Int) {
        // CORREÇÃO: Atualiza a variável global de data para evitar duplicação no salvamento
        this.dataSelecionadaMillis = data

        with(binding) {
            edtDescricao.setText(desc)

            // CORREÇÃO: Remove o watcher real para setar o valor formatado com sucesso
            val valorFormatado = NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(valor)
            edtValor.post {
                edtValor.removeTextChangedListener(valorWatcher)
                edtValor.setText(valorFormatado)
                edtValor.setSelection(valorFormatado.length)
                edtValor.addTextChangedListener(valorWatcher)
            }

            if (tipo == TipoLancamento.RECEITA) rbReceita.isChecked = true else rbDespesa.isChecked = true
            atualizarVisibilidadeCategoria(tipo == TipoLancamento.DESPESA)

            val cal = Calendar.getInstance().apply { timeInMillis = data }
            atualizarTextoData(cal)

            val posicao = categorias.indexOfFirst { it.id == catId }
            if (posicao != -1) spinnerCategorias.setSelection(posicao)

            if (isAgenda) {
                containerRepetir.visibility = View.VISIBLE
                chkRepetir.isEnabled = false
                chkRepetir.text = "Repetição desabilitada na edição"
            } else {
                containerRepetir.visibility = View.GONE
            }
        }
    }

    private fun configurarBotaoSalvar() {
        binding.btnSalvarLancamento.setOnClickListener {
            val descricao = binding.edtDescricao.text.toString()
            val cleanValor = binding.edtValor.text.toString().replace(Regex("[^0-9]"), "")

            if (descricao.isBlank() || cleanValor.isBlank()) {
                Toast.makeText(this, "Preencha os campos obrigatórios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val valorFinal = cleanValor.toDouble() / 100
            val tipo = if (binding.rbReceita.isChecked) TipoLancamento.RECEITA else TipoLancamento.DESPESA
            val pos = binding.spinnerCategorias.selectedItemPosition
            val catId = if (tipo == TipoLancamento.DESPESA && pos != AdapterView.INVALID_POSITION) {
                categorias[pos].id
            } else {
                categorias.find { it.nome.contains("Receita", true) }?.id ?: 1
            }

            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    if (isAgenda) {
                        val repetir = binding.chkRepetir.isChecked
                        val qtdMesesStr = binding.edtQtdMeses.text.toString()
                        val qtdMeses = if (repetir && qtdMesesStr.isNotEmpty()) qtdMesesStr.toInt() else 1
                        val calAux = Calendar.getInstance().apply { timeInMillis = dataSelecionadaMillis }

                        for (i in 0 until qtdMeses) {
                            val agenda = Agenda(
                                id = if (i == 0 && idEdicao != -1) idEdicao else 0,
                                descricao = if (qtdMeses > 1) "$descricao (${i + 1}/$qtdMeses)" else descricao,
                                valor = valorFinal,
                                data = calAux.timeInMillis,
                                categoriaID = catId,
                                tipo = tipo
                            )
                            db.agendaDao().upsertAgenda(agenda)
                            calAux.add(Calendar.MONTH, 1)
                        }
                    } else {
                        val lancamento = Lancamento(
                            id = if (idEdicao != -1) idEdicao else 0,
                            descricao = descricao,
                            valor = valorFinal,
                            data = dataSelecionadaMillis,
                            categoriaID = catId,
                            tipo = tipo
                        )
                        db.orcamentoDao().upsertLancamento(lancamento)
                    }
                }
                Toast.makeText(this@NovoLancamentoActivity, "Salvo com sucesso!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun atualizarDescricaoPelaCategoria() {
        val pos = binding.spinnerCategorias.selectedItemPosition
        if (pos != AdapterView.INVALID_POSITION && categorias.isNotEmpty()) {
            binding.edtDescricao.setText(categorias[pos].nome)
            binding.edtDescricao.setSelection(binding.edtDescricao.text?.length ?: 0)
        }
    }

    private fun configurarCampoData() {
        binding.edtData.setOnClickListener {
            val cal = Calendar.getInstance().apply { timeInMillis = dataSelecionadaMillis }
            DatePickerDialog(this, { _, ano, mes, dia ->
                cal.set(ano, mes, dia)
                atualizarTextoData(cal)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
    }

    private fun atualizarTextoData(cal: Calendar) {
        val formato = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        binding.edtData.setText(formato.format(cal.time))
        dataSelecionadaMillis = cal.timeInMillis
    }

    private fun configurarMudancaDeTipo() {
        binding.radioGroupTipo.setOnCheckedChangeListener { _, checkedId ->
            val isDespesa = checkedId == R.id.rbDespesa
            atualizarVisibilidadeCategoria(isDespesa)
            if (idEdicao == -1) {
                if (isDespesa) atualizarDescricaoPelaCategoria()
                else binding.edtDescricao.setText("Receita")
            }
        }
    }

    private fun atualizarVisibilidadeCategoria(isDespesa: Boolean) {
        val vis = if (isDespesa) View.VISIBLE else View.GONE
        binding.lblCategoria.visibility = vis
        binding.spinnerCategorias.visibility = vis
    }

    private fun configurarCampoValor() {
        binding.edtValor.addTextChangedListener(valorWatcher)
    }
}