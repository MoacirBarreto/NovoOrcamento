package devandroid.moacir.novoorcamento.model

enum class TipoLancamento {
    RECEITA,
    DESPESA
}