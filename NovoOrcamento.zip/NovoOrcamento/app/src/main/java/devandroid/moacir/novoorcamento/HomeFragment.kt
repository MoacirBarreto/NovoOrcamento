package devandroid.moacir.novoorcamento

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import devandroid.moacir.novoorcamento.database.AppDatabase
import devandroid.moacir.novoorcamento.databinding.FragmentHomeBinding
import devandroid.moacir.novoorcamento.model.Lancamento
import devandroid.moacir.novoorcamento.model.TipoLancamento
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class HomeFragment : Fragment() {

    // Configuração do ViewBinding para Fragments
    private var _binding: FragmentHomeBinding? = null
    // Essa propriedade só é válida entre onCreateView e onDestroyView
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inicializa o Banco de Dados (usando requireContext() em vez de this)
        db = AppDatabase.getDatabase(requireContext())

        configurarRecyclerView()
        configurarFab()
        configurarFiltros()
    }

    override fun onResume() {
        super.onResume()
        // Recarrega a lista sempre que o fragmento volta a aparecer (ex: voltou do cadastro)
        carregarLista(binding.chipGroupFiltros.checkedChipId)
    }

    private fun configurarRecyclerView() {
        binding.rvLancamentos.layoutManager = LinearLayoutManager(requireContext())
    }

    private fun configurarFab() {
        binding.fabAdicionar.setOnClickListener {
            val intent = Intent(requireContext(), NovoLancamentoActivity::class.java)
            startActivity(intent)
        }
    }

    private fun configurarFiltros() {
        binding.chipGroupFiltros.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                carregarLista(checkedIds[0])
            }
        }
    }

    private fun carregarLista(chipId: Int) {
        val listaFiltrada: List<Lancamento>
        val calendario = Calendar.getInstance()

        // Zera horário para consistência
        calendario.set(Calendar.HOUR_OF_DAY, 0)
        calendario.set(Calendar.MINUTE, 0)
        calendario.set(Calendar.SECOND, 0)

        when (chipId) {
            R.id.chipMesAtual -> {
                calendario.set(Calendar.DAY_OF_MONTH, 1)
                val dataInicio = calendario.timeInMillis
                listaFiltrada = db.orcamentoDao().listarLancamentosPorPeriodo(dataInicio, Long.MAX_VALUE)
            }
            R.id.chip30Dias -> {
                calendario.add(Calendar.DAY_OF_YEAR, -30)
                val dataInicio = calendario.timeInMillis
                listaFiltrada = db.orcamentoDao().listarLancamentosPorPeriodo(dataInicio, Long.MAX_VALUE)
            }
            else -> {
                listaFiltrada = db.orcamentoDao().listarLancamentos()
            }
        }

        atualizarRecyclerView(listaFiltrada)
        atualizarResumo(listaFiltrada)
    }

    private fun atualizarRecyclerView(lista: List<Lancamento>) {
        val adapter = LancamentoAdapter(
            lista,
            onItemClick = { lancamento -> abrirTelaDeEdicao(lancamento) },
            onItemLongClick = { lancamento -> exibirDialogoDeExclusao(lancamento) }
        )
        binding.rvLancamentos.adapter = adapter
    }

    private fun atualizarResumo(lista: List<Lancamento>) {
        val totalReceitas = lista.filter { it.tipo == TipoLancamento.RECEITA }.sumOf { it.valor }
        val totalDespesas = lista.filter { it.tipo == TipoLancamento.DESPESA }.sumOf { it.valor }
        val saldo = totalReceitas - totalDespesas

        val formato = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

        binding.txtTotalReceitas.text = formato.format(totalReceitas)
        binding.txtTotalDespesas.text = formato.format(totalDespesas)
        binding.txtSaldoFinal.text = formato.format(saldo)

        // Contexto seguro para pegar cores
        val context = requireContext()
        if (saldo >= 0) {
            binding.txtSaldoFinal.setTextColor(ContextCompat.getColor(context, R.color.green))
        } else {
            binding.txtSaldoFinal.setTextColor(ContextCompat.getColor(context, R.color.red))
        }
    }

    private fun abrirTelaDeEdicao(lancamento: Lancamento) {
        val intent = Intent(requireContext(), NovoLancamentoActivity::class.java)
        intent.putExtra("LANCAMENTO_ID", lancamento.id)
        startActivity(intent)
    }

    private fun exibirDialogoDeExclusao(lancamento: Lancamento) {
        AlertDialog.Builder(requireContext())
            .setTitle("Excluir Lançamento")
            .setMessage("Tem certeza que deseja excluir '${lancamento.descricao}'?")
            .setPositiveButton("Sim") { _, _ ->
                db.orcamentoDao().deletarLancamento(lancamento)
                carregarLista(binding.chipGroupFiltros.checkedChipId)
            }
            .setNegativeButton("Não", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
