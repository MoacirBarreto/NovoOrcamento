package devandroid.moacir.novoorcamento

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import devandroid.moacir.novoorcamento.database.AppDatabase
import devandroid.moacir.novoorcamento.databinding.FragmentGraficosBinding
import devandroid.moacir.novoorcamento.model.Lancamento
import devandroid.moacir.novoorcamento.model.TipoLancamento
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class GraficosFragment : Fragment() {

    private var _binding: FragmentGraficosBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGraficosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        configurarGraficoBarrasInicial()
        configurarGraficoPizzaInicial()
        configurarFiltros()
    }

    override fun onResume() {
        super.onResume()
        val chipId = binding.chipGroupFiltrosGrafico.checkedChipId
        carregarDadosGrafico(chipId)
    }

    private fun configurarFiltros() {
        binding.chipGroupFiltrosGrafico.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                carregarDadosGrafico(checkedIds[0])
            }
        }
    }

    private fun carregarDadosGrafico(chipId: Int) {
        val calendario = Calendar.getInstance()
        val listaFiltrada: List<Lancamento>

        calendario.set(Calendar.HOUR_OF_DAY, 0)
        calendario.set(Calendar.MINUTE, 0)
        calendario.set(Calendar.SECOND, 0)

        when (chipId) {
            R.id.chipMesAtualGrafico -> {
                calendario.set(Calendar.DAY_OF_MONTH, 1)
                val dataInicio = calendario.timeInMillis
                listaFiltrada = db.orcamentoDao().listarLancamentosPorPeriodo(dataInicio, Long.MAX_VALUE)
            }
            R.id.chip30DiasGrafico -> {
                calendario.add(Calendar.DAY_OF_YEAR, -30)
                val dataInicio = calendario.timeInMillis
                listaFiltrada = db.orcamentoDao().listarLancamentosPorPeriodo(dataInicio, Long.MAX_VALUE)
            }
            else -> {
                listaFiltrada = db.orcamentoDao().listarLancamentos()
            }
        }

        atualizarGraficoBarras(listaFiltrada)
        atualizarGraficoPizza(listaFiltrada)
    }

    // --- GRÁFICO DE BARRAS ---
    private fun configurarGraficoBarrasInicial() {
        binding.barChart.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setDrawGridBackground(false)
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false)
            xAxis.granularity = 1f
            xAxis.valueFormatter = IndexAxisValueFormatter(listOf("Receitas", "Despesas"))
            axisRight.isEnabled = false
            axisLeft.axisMinimum = 0f
            axisLeft.setDrawGridLines(true)
        }
    }

    private fun atualizarGraficoBarras(lista: List<Lancamento>) {
        val totalReceitas = lista.filter { it.tipo == TipoLancamento.RECEITA }.sumOf { it.valor }
        val totalDespesas = lista.filter { it.tipo == TipoLancamento.DESPESA }.sumOf { it.valor }

        val entries = ArrayList<BarEntry>()
        entries.add(BarEntry(0f, totalReceitas.toFloat()))
        entries.add(BarEntry(1f, totalDespesas.toFloat()))

        val dataSet = BarDataSet(entries, "Resumo").apply {
            val corReceita = ContextCompat.getColor(requireContext(), R.color.green)
            val corDespesa = ContextCompat.getColor(requireContext(), R.color.red)
            colors = listOf(corReceita, corDespesa)
            valueTextSize = 14f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    val formato = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
                    return formato.format(value.toDouble())
                }
            }
        }

        val data = BarData(dataSet)
        data.barWidth = 0.5f
        binding.barChart.data = data
        binding.barChart.invalidate()
        binding.barChart.animateY(1000)
    }

    // --- GRÁFICO DE PIZZA ---
    private fun configurarGraficoPizzaInicial() {
        binding.pieChart.apply {
            description.isEnabled = false
            isDrawHoleEnabled = true
            holeRadius = 45f
            transparentCircleRadius = 50f
            setHoleColor(Color.TRANSPARENT)
            setDrawCenterText(true)
            centerText = "Despesas"
            setCenterTextSize(16f)
            legend.isEnabled = false
            setEntryLabelColor(Color.BLACK)
            setEntryLabelTextSize(11f)
        }
    }

    private fun atualizarGraficoPizza(lista: List<Lancamento>) {
        // 1. O FILTRO DE OURO: Pegar apenas o que é DESPESA
        val despesas = lista.filter { it.tipo == TipoLancamento.DESPESA }

        // Se não tiver despesa nenhuma no período, limpa o gráfico e avisa
        if (despesas.isEmpty()) {
            binding.pieChart.clear()
            binding.pieChart.centerText = "Sem Despesas"
            return
        } else {
            binding.pieChart.centerText = "Despesas"
        }

        // 2. Busca nomes das categorias (Mapeamento ID -> Nome)
        // Isso assume que você tem esse metodo no DAO. Se não tiver, avise!
        val mapaCategorias = db.orcamentoDao().listarCategorias().associate { it.id to it.nome }

        // 3. Agrupar os valores por Categoria
        val gastosPorCategoria = despesas
            .groupBy { it.categoriaID } // Agrupa pelo ID da categoria
            .map { (catId, lancamentos) ->
                // Pega o nome real ou usa "Outros" se não achar
                val nomeCategoria = mapaCategorias[catId] ?: "Outros"
                // Soma os valores dessa categoria
                val total = lancamentos.sumOf { it.valor }

                nomeCategoria to total // Cria um par (Nome, ValorTotal)
            }
            .sortedByDescending { it.second } // Ordena do maior gasto para o menor

        // 4. Transformar em dados para o gráfico (PieEntry)
        val entries = ArrayList<PieEntry>()
        gastosPorCategoria.forEach { (nome, valor) ->
            // O gráfico aceita Float, então convertemos o Double
            entries.add(PieEntry(valor.toFloat(), nome))
        }

        // 5. Configuração Visual (Cores, Texto, etc)
        val dataSet = PieDataSet(entries, "Categorias").apply {
            colors = ColorTemplate.MATERIAL_COLORS.toList() // Cores bonitas automáticas
            sliceSpace = 3f // Espacinho entre as fatias
            valueTextSize = 12f
            valueTextColor = Color.WHITE

            // Formatação para R$ dentro da fatia
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    val formato = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
                    return formato.format(value.toDouble())
                }
            }
        }

        // 6. Joga os dados na tela
        val data = PieData(dataSet)
        binding.pieChart.data = data
        binding.pieChart.invalidate() // Atualiza o desenho
        binding.pieChart.animateY(1400) // Animação
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
